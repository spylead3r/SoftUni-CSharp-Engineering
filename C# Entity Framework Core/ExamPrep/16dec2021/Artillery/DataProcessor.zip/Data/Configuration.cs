﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8QI7GMD\SQLEXPRESS;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
